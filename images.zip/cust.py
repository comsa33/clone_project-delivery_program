import sys
import pickle
from datetime import date
from PyQt5.QtWidgets import *
from PyQt5.QtGui import QStandardItem
from PyQt5.QtGui import QStandardItemModel
from PyQt5.QtWidgets import QWidget
from PyQt5.QtCore import *
from PyQt5.QtWidgets import QApplication
from PyQt5 import QtGui
from PyQt5 import uic


form_class = uic.loadUiType("cust.ui")[0]

class CustApp(QMainWindow, form_class):
    import BaeMin_rc
    list=['상준이네 치킨집','소요시간 54~60분','별점:4.8']
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.btn_home.clicked.connect(lambda: self.goindex(1))
        self.btn_search.clicked.connect(lambda: self.goindex(2))
        self.btn_like.clicked.connect(lambda: self.goindex(3))
        self.btn_history.clicked.connect(lambda: self.goindex(4))
        self.btn_myinfo.clicked.connect(lambda: self.goindex(5))
        self.listadd_btn.clicked.connect(lambda: self.add(1))
        self.like_btn.clicked.connect(lambda : self.SJ_likewidget(1))  # 찜한가게
        self.pay_atonce_btn.clicked.connect(lambda : self.SJ_likewidget(2))  #바로결제
        self.paybycall_btn.clicked.connect(lambda : self.SJ_likewidget(3))   # 전화주문
        self.like_btn.setCheckable(True)
        self.pay_atonce_btn.setCheckable(True)
        self.paybycall_btn.setCheckable(True)
        self.like_label_ment.setText(f'총{self.listWidget.count()}개')
        self.label_ment2.setText(f'총{self.listWidget2.count()}개')




    def goindex(self, index_no):
        self.stackedWidget.setCurrentIndex(index_no-1)

    def SJ_likewidget(self,index_no):  #찜한가게 바로결제 전화주문으로 넘어가는 함수
        if self.listWidget.count()==0:
            self.likedwidget.setCurrentIndex(index_no-1)
        if self.listWidget2.count()==0:
            self.likedwidget.setCurrentIndex(index_no-1)

        self.likedwidget.setCurrentIndex(index_no-1)







    def add(self,x):
        self.a=self.list[x-1]
        self.b=self.list[x]
        self.c=self.list[x+1]
        self.listWidget.addItem(self.a+'\n'+self.b +'\n'+self.c)









if __name__ == "__main__":
    app = QApplication(sys.argv)
    form = CustApp()
    form.show()
    exit(app.exec_())